import { forwardRef, useImperativeHandle, useState } from 'react';

/*
const Child = () => {
	return (
		<article>
			<h1>Child</h1>
		</article>
	);
};
*/
const Child = forwardRef((props, ref) => {
	const [Open, setOpen] = useState(false);

	useImperativeHandle(ref, () => {
		return { toggle: () =>setOpen(!Open) };
	});

	return (
		<article ref={ref}>
			<h1>Child</h1>
		</article>
	);
});

export default Child;
