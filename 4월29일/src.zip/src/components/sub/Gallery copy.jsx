import Layout from '../common/Layout';
import axios from 'axios';
import Masonry from 'react-masonry-component';
import Modal from '../common/Modal';
import { useState, useEffect, useRef } from 'react';

function Gallery() {
	const modal = useRef(null);
	const frame = useRef(null);
	const input = useRef(null);
	const [Items, setItems] = useState([]);
	const [Loading, setLoading] = useState(true);
	const [Index, setIndex] = useState(0);

	const getFlickr = async (opt) => {
		const baseURL =
			'https://www.flickr.com/services/rest/?format=json&nojsoncallback=1&privacy_filter=1';
			 //공통링크
		const key = 'ae5dbef0587895ed38171fcda4afb648';
		const method_interest = 'flickr.interestingness.getList';
		const method_search = 'flickr.photos.search';
		const method_user = 'flickr.people.getPhotos';
		const num = 500; //원하는 갯수
		let url = '';

		//인수로 전달되는 opt객체의 type값에 따라 요청 url 분기처리
		if (opt.type === 'interest')
			url = `${baseURL}&api_key=${key}&method=${method_interest}&per_page=${num}`;
		//interest 방식

		if (opt.type === 'search')
			url = `${baseURL}&api_key=${key}&method=${method_search}&per_page=${num}&tags=${opt.tags}`;
		//서치방식(태그값필요)

		if (opt.type === 'user')
			url = `${baseURL}&api_key=${key}&method=${method_user}&per_page=${num}&user_id=${opt.user}`;
		//유저값

		const result = await axios.get(url);
		setItems(result.data.photos.photo);
		// console.log(result.data.photos.photo);

		//이미지정보가 받아지고 masonry에 의해 레이아웃 정렬되는 시간 0.5s 이후에
		//로딩바 없애고 갤러리 화면 출력
		setTimeout(() => {
			setLoading(false);
			frame.current.classList.add('on');
		}, 1000);
	};

	//컴포넌트 마운트시 데이터호출 함수 실행
	useEffect(() => {
		//interest방식의 이미지 데이터 호출
		getFlickr({ type: 'interest' });

		//검색어의 내용으로 이미지 데이터 호출
		//getFlickr({ type: 'search', tags: 'city ' });

		//사용자 아이디명으로 이미지 데이터 호출
		//getFlickr({ type: 'user', user: '137893408@N06' });
		//아이디명을 user에 넣었을때 그 아이디명만 검색할 수 있음
	}, []);

	return (
		<>
		<Layout name={'Gallery'}>
			{/* 각 버튼 클릭시 로딩바 출력되었다가 갤러리 전환이 완료되면 컨체트 보임처리 */}
			{/* <button
				onClick={() => {
					getFlickr({ type: 'interest' });
				}}
			>
				Interest Gallery
			</button> */}
			<div className='controls'>
				<div className='searchBox'>
					<input type='text' placeholder='검색어를 입력하세요.' ref={input} />
					<button
						onClick={() => {
							getFlickr({ type: 'search', tags: input.current.value });
							setLoading(true);
							frame.current.classList.remove('on');
						}}
					>
						Search
					</button>
				</div>
			</div>

			<button
				onClick={() => {
					getFlickr({ type: 'interest' });
					frame.current.classList.remove('on');
					setLoading(true);
				}}
			>
				Interest Gallery
			</button>

			<button
				onClick={() => {
					getFlickr({ type: 'user', user: '137893408@N06' });
					frame.current.classList.remove('on');
					setLoading(true);
				}}
			>
				User Gallery
			</button>

			
			{/* 이미지 불러옴 */}
			{Loading && (
				<img
					className='loader'
					src={`${process.env.PUBLIC_URL}/img/loading.gif`}
					alt='loading bar'
				/>
			)}
		

		<div className='frame' ref={frame}>
			<Masonry elementType={'div'} options={{ transitionDuration: '0.5s' }}>
				{Items.map((item, idx) => {
					return (
						<article key={idx}>
							<div className='inner'>
								<div className='pic'>
										<img
											src={`https://live.staticflickr.com/${item.server}/${item.id}_${item.secret}_m.jpg`}
											alt={item.title}
										/>
										{/* //갤러리에 프로필 연결 */}
									</div>

								<h2>{item.title}</h2>

								<div className='profile'>
									<img
										src={`http://farm${item.farm}.staticflickr.com/${item.server}/buddyicons/${item.owner}.jpg`}
										alt={item.owner}
										onError={(e) => {
											e.target.setAttribute('src', 'https://www.flickr.com/images/buddyicon.gif');
										}}
									/>	{/* //갤러리에 프로필 네임 연결 */}
									{/* <span>{item.owner}</span> */}
									<span
											onClick={(e) => {
												getFlickr({
													type: 'user',
													user: e.target.innerText,
												});
												setLoading(true);
												frame.current.classList.remove('on');
											}}
										>
											{item.owner}
										</span>
								</div>
							</div>
						</article>
					);
				})}
				<div className='my-bg-image-el'></div>
				</Masonry>
			</div>
		</Layout>
		
		<Modal ref={modal}>
				<img
					src={`https://live.staticflickr.com/${Items[Index]?.server}/${Items[Index]?.id}_${Items[Index]?.secret}_b.jpg`}
					alt={Items[Index]?.title}
				/>
		</Modal>
		</>
	);
}

export default Gallery;