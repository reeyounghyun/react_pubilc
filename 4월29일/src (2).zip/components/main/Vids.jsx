function Vids() {
	return (
		<section id='vids' className='myScroll'>
			<h1>Youtube</h1>
		</section>
	);
}

export default Vids;
