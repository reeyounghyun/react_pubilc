import { useState, forwardRef, useImperativeHandle } from 'react';
import {motion, AnimataPresnce} form 'ftamer-motion';

const Modal = forwardRef((props, ref) => {
	const [Open, setOpen] = useState(false);

	useImperativeHandle(ref, () => {
		return { open: () => setOpen(true) };
	});

	//부모에서 컨텐츠는 비어져 있을지언정 컴포넌트 자체는 계속 마운트되어 있으므로 useEffect를 활용한 스크롤 생성 유무 로직을 활용 불가능

	return (
		<AnimataPresnce>
			{Open && (
				<motion.aside className='modal'
					initial={{opacity:0}}
					animate={{opacity:1, transition:{duration:3}}}
					exit={{opacity:0}}>
					<div className='con'>{props.children}</div>
					<span className='close' onClick={() => setOpen(false)} 
						initial={{x:100, opacity:0}} 
						animate={{duration:0.5, delay:0.5}}
						exit={{x:-100, opcity:0}}>
						Close
					</span>
				</motion.aside>
			)}
		</AnimataPresnce>
	);
});

//https://www.framer.com/motion/component/

export default Modal;
