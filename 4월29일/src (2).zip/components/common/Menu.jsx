import React from 'react';

function Menu() {
	return <div>Menu</div>;
}

export default Menu;
